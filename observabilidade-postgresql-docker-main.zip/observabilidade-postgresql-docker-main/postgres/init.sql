-- Script para criar uma tabela de exemplo
CREATE TABLE exemplo (
    id SERIAL PRIMARY KEY,
    nome TEXT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO exemplo (nome) VALUES ('teste 1'), ('teste 2');