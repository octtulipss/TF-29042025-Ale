# Relatório Técnico

## Decisões Tomadas

- Utilização de Prometheus e Grafana por sua ampla adoção.
- Exporter oficial da comunidade Prometheus para PostgreSQL.
- Configuração simples com Docker Compose.

## Desafios

- Alinhar os tempos de scrape com a frequência de atualizações do banco.
- Ajustar permissões e conexão do exporter.

## Lições Aprendidas

- A observabilidade é facilitada com ferramentas bem integradas.
- Monitorar em desenvolvimento ajuda a prever gargalos em produção.