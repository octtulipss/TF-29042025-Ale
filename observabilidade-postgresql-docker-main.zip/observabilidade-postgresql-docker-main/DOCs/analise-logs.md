# Análise de Logs PostgreSQL

A partir da configuração padrão do PostgreSQL, podemos observar logs como:

- Conexões estabelecidas
- Execução de queries
- Transações longas ou falhas

## Exemplo

```
2025-04-30 12:00:00.000 UTC [32] LOG:  connection received: host=172.19.0.1 port=5432
2025-04-30 12:00:05.000 UTC [32] LOG:  statement: SELECT * FROM exemplo;
```